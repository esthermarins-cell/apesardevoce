const express = require('express');
const dotenv = require('dotenv');
const rotas = require('./routes');

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

app.use('/api', rotas);

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});