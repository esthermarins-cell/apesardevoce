const express = require('express');
const router = express.Router();

const noticiasController = require('../controllers/noticiasController');
const usuariosController = require('../controllers/usuariosController');

router.get('/', (req, res) => {
    res.json({
        message: 'Bem-vindo à API!',
    });
});

router.get('/noticias', noticiasController.listarNoticias);
router.post('/usuarios', usuariosController.cadastrarUsuario);

module.exports = router;