function cadastrarUsuario(req, res) {
    const { nome, email } = req.body;

    if (!nome || !email) {
        return res.status(400).json({
            erro: 'Nome e e-mail são obrigatórios.'
        });
    }

    res.status(201).json({
        mensagem: 'Dados recebidos para cadastro!',
        usuario: {
            nome,
            email
        }
    });
}

module.exports = {
    cadastrarUsuario
};