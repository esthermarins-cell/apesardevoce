function listarNoticias(req, res) {
    // Lógica para listar notícias
    res.json({ 
        message: 'Listando notícias',
        noticias: []
     });
}

module.exports = {
    listarNoticias
};
